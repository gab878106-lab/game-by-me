# € Clicker — GitHub Pages + Supabase

Cette version garde le jeu et ajoute l'inscription, la connexion et la sauvegarde cloud.

## Configuration Supabase

1. Crée un projet sur Supabase.
2. Ouvre **SQL Editor** et exécute tout `supabase.sql`.
3. Récupère l'URL de ton projet et sa **Publishable key**.
4. Dans `index.html`, remplace :

```js
const SUPABASE_URL = "TON_URL_SUPABASE";
const SUPABASE_PUBLISHABLE_KEY = "TA_CLE_PUBLISHABLE_SUPABASE";
```

Ne mets **jamais** une clé `service_role` dans le navigateur.

Par défaut, Supabase peut demander la confirmation de l'adresse e-mail après l'inscription. Si tu veux tester sans cette étape, adapte le réglage de confirmation e-mail dans Authentication de ton projet.

## GitHub Pages

Mets `index.html`, `supabase.sql` et `README.md` dans ton dépôt GitHub, puis active GitHub Pages dans les réglages du dépôt.

Le navigateur héberge le jeu via GitHub Pages ; Supabase fournit l'authentification et la base PostgreSQL. La partie est associée à l'identifiant Supabase de l'utilisateur et protégée par Row Level Security.

## Important

Cette version convient à un clicker classique. Pour un jeu compétitif ou une monnaie ayant une vraie valeur, il faudrait déplacer les calculs sensibles côté serveur afin de rendre l'économie résistante à la triche.
